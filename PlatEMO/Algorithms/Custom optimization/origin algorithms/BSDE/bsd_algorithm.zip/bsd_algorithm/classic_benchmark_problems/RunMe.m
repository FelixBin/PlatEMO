

load FncData

%  see benchmark_fnc_list.pdf for the list of the benchmark functions and 'fncnumber'

fncnumber=41; 

fnc=Fnc{fncnumber}; 
low=FncLow(fncnumber); 
up=FncUp(fncnumber); 
dim=FncDim(fncnumber);
algo_bsd(fnc,[],30,dim,low,up,100e5)



